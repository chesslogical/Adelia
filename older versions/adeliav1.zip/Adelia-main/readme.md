
ADELIA is based on Claire, tinyib, tinyboard, vichan, lynxchan, and fchannel. 


File Upload Board with Actix Web

This is a simple image board implemented using Actix Web in Rust. Super tiny codebase, has features of modern imageboards. Uses sqlite3. Recommended to run a separate instance for each board, for example confiture nginx /reverse proxy to run /a and /b and /c as separate instances of the app on the same port. You start and stop each instance separately.



![Screenshot 2024-05-28 025835](https://github.com/ChessLogical/Adelia/assets/169053333/1d4d7ba9-3930-4921-a7b2-2d659470cb63)






